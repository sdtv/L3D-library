This is a Processing library for drawing and streaming graphics to LED cubes.
It's structured around the [L3D cube](http://www.l3dcube.com), which I make, 
but it could be used as a cube simulator for any cube, or extended to stream
data to any cube that can accept it.

There's an in-depth tutorial [at instructables](http://www.instructables.com/id/How-to-Draw-Sweet-3D-Graphics-for-LED-cubes/).

If you make something awesome, let me know at alex@lookingglassfactory.com

Enjoy!